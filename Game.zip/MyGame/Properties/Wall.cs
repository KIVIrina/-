﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    class Wall
    {
        private PictureBox CurrentWall = new PictureBox();

        public Wall(int width, int height, Point position)
        {
            CurrentWall.Width = width;
            CurrentWall.Height = height;
            CurrentWall.Location = position;
            CurrentWall.Tag = "platform";
            CurrentWall.BackColor = Color.Brown; //
        }

        public void DrowTo(Form form)
        {
            form.Controls.Add(CurrentWall);
        }

        public Rectangle GetBounds()
        {
            return CurrentWall.Bounds;
        }
    }
}
