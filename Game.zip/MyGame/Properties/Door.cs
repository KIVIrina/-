﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    class Door
    {
        private PictureBox MyDoor = new PictureBox();
        public bool IsDoorOpen;

        public Door()
        {
            MyDoor.Width = 40;
            MyDoor.Height = 70;
            MyDoor.BackColor = Color.Black; //
            IsDoorOpen = false;
            MyDoor.Location = new Point(845, 450);
        }

        public void DrowTo(Form form)
        {
            form.Controls.Add(MyDoor);
        }

        public Rectangle GetBounds()
        {
            return MyDoor.Bounds;
        }

        public void SetPosition(int x, int y)
        {
            MyDoor.Location = new Point(x, y);
        }

        public void OpenDoor()
        {
            IsDoorOpen = true;
            MyDoor.BackColor = Color.Gray;
        }
    }
}
