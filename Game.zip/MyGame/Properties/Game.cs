﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    class Game
    {
        public Keys KeyPressed;
        public List<Wall> NormalWallPosition = new List<Wall>() { new Wall(40, 450, new Point(0,0)),
            new Wall(40, 450, new Point(845,0)),
            new Wall(900, 40, new Point(0,0)),
            new Wall(350, 40, new Point(0, 520)),
            new Wall(350, 40, new Point(550, 520))};
        //public Door Door = new Door();
        public int MapWidth = 860;
        public int MapHeightl = 560;
        
        public void MakeLevel(int level)
        {
            
        }

    }
}
