﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    class Player
    {
        private PictureBox MyPlayer = new PictureBox();
        bool goLeft = false;
        bool goRight = false;
        bool jumping = false;

        int jumpSpeed = 10;
        int force = 8;
        int level = 0;

        public Player()
        {
            MyPlayer.Width = 30;
            MyPlayer.Height = 50;
            MyPlayer.BackColor = Color.Brown;
        }

        public void DrowTo(Form form)
        {
            form.Controls.Add(MyPlayer);
        }

        public Rectangle GetBounds()
        {
            return MyPlayer.Bounds;
        }

        public void SetPosition(int x, int y)
        {
            MyPlayer.Location = new Point(x, y);
        }
    }
}
