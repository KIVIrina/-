﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGame
{
    public partial class Form1 : Form
    {
        bool goLeft = false;
        bool goRight = false;
        bool jumping = false;

        int jumpSpeed = 10;
        int force = 8;
        int level = 0;
        Point StartPoint = new Point(41, 450);
        

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Space:
                    jumping = true;
                    break;
                case Keys.Right:
                    goRight = true;
                    break;
                case Keys.Left:
                    goLeft = true;
                    break;
            }   
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Space:
                    jumping = false;
                    break;
                case Keys.Right:
                    goRight = false;
                    break;
                case Keys.Left:
                    goLeft = false;
                    break;
            }
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(player.Top + player.Height > 560)
            {
                player.Location = StartPoint;
            }

            var game = new Game();
            foreach (var wall in game.NormalWallPosition)
            {
                wall.DrowTo(this);
            }

            var door = new Door();
            door.DrowTo(this);
            door.OpenDoor();

            player.Top += jumpSpeed;
            if (jumping && force < 0)
                jumping = false;

            if (goLeft && player.Left - 5 > 0 )
                player.Left -= 5;

            if (goRight && player.Left + 5 < game.MapWidth)
                player.Left += 5;

            if (jumping)
            {
                jumpSpeed = -12;
                force -= 1;
            }
            else
                jumpSpeed = 12;

            foreach(Control x in Controls)
            {
                if (x is PictureBox)
                {
                    if (player.Bounds.IntersectsWith(x.Bounds) && !jumping && x.Tag == "platform")
                    {
                        force = 8;
                        player.Top = x.Top - player.Height;
                    }

                    if (player.Bounds.IntersectsWith(door.GetBounds()) && door.IsDoorOpen)
                    {
                        level++;
                        Level.Text = "Level: " + level;
                        game.MakeLevel(level);
                    }
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void timer3_Tick(object sender, EventArgs e)
        {

        }
    }
}
